(function() {
"use strict";

	var selectedIdx = document.getElementById('s-state').selectedIndex;
	var selectedValue = document.getElementById('s-state').option[selectedIdx].value;

})();