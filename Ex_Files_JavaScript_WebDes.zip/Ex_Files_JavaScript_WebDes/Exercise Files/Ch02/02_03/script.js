(function() {
"use strict";

var variable1 = 2, variable2 = "hello";

console.log(variable1);
console.log("This is variable2", variable2);

})();